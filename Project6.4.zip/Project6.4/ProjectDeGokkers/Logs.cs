﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project6
{
    public partial class Logs : Form
    {
        public Logs()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            // de naam van een van de player hier zetten 
            // ook bij de andere van deze rij dat doen
        }

        private void label6_Click(object sender, EventArgs e)
        {
            // hier de winst van de bijhorende player 
            // ook bij de andere van deze rij dat doen
        }

        private void label7_Click(object sender, EventArgs e)
        {
            // hier de Verlies van de bijhorende player 
            // ook bij de andere van deze rij dat doen
        }

        private void label8_Click(object sender, EventArgs e)
        {
            // hier de Eindsaldo van de bijhorende player 
            // ook bij de andere van deze rij dat doen
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // als de user hier op clickt dan terug gaan naar de mainscreen
        }
    }
}
