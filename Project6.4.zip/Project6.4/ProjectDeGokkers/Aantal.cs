﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project6
{
    public partial class Aantal : Form
    {
        public Aantal()
        {
            InitializeComponent();
        }

        private void PlayerNumber_ValueChanged(object sender, EventArgs e)
        {
            // dit in een variable zetten en er voor zorgen dat het aantal Form3 
            // op popt als je op go clicked en dat er dan met iets met de players gebeurt op de mainscreen
        }

        private void Go_Click(object sender, EventArgs e)
        {

        }
    }
}
