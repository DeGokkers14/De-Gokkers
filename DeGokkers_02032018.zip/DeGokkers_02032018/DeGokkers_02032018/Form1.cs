﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeGokkers_02032018
{
    public partial class frmUsernameInput : Form
    {
        public static string player1;
        public static string player2;
        public static string player3;

        public frmUsernameInput()
        {
            InitializeComponent();
        }

        private void btnStartGame_Click(object sender, EventArgs e)
        {
            player1 = tbPlayerName1.Text;
            player2 = tbPlayerName2.Text;
            player3 = tbPlayerName3.Text;

            frmBets form2 = new frmBets();
            form2.Show();
            this.Hide();
        }
    }
}
