﻿namespace DeGokkers_02032018
{
    partial class frmBets
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBets));
            this.pbDog4 = new System.Windows.Forms.PictureBox();
            this.pbDog3 = new System.Windows.Forms.PictureBox();
            this.pbDog2 = new System.Windows.Forms.PictureBox();
            this.pbDog1 = new System.Windows.Forms.PictureBox();
            this.pbRacetrack = new System.Windows.Forms.PictureBox();
            this.btnRun = new System.Windows.Forms.Button();
            this.btnPlaceBet = new System.Windows.Forms.Button();
            this.rbtnPlayer1 = new System.Windows.Forms.RadioButton();
            this.rbtnPlayer2 = new System.Windows.Forms.RadioButton();
            this.rbtnPlayer3 = new System.Windows.Forms.RadioButton();
            this.lbPlayer1 = new System.Windows.Forms.Label();
            this.lbPlayer2 = new System.Windows.Forms.Label();
            this.lbPlayer3 = new System.Windows.Forms.Label();
            this.udMoney = new System.Windows.Forms.NumericUpDown();
            this.udDogs = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.Movement = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbDog4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRacetrack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udMoney)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.udDogs)).BeginInit();
            this.SuspendLayout();
            // 
            // pbDog4
            // 
            this.pbDog4.Image = ((System.Drawing.Image)(resources.GetObject("pbDog4.Image")));
            this.pbDog4.Location = new System.Drawing.Point(17, 221);
            this.pbDog4.Margin = new System.Windows.Forms.Padding(4);
            this.pbDog4.Name = "pbDog4";
            this.pbDog4.Size = new System.Drawing.Size(103, 25);
            this.pbDog4.TabIndex = 9;
            this.pbDog4.TabStop = false;
            // 
            // pbDog3
            // 
            this.pbDog3.Image = ((System.Drawing.Image)(resources.GetObject("pbDog3.Image")));
            this.pbDog3.Location = new System.Drawing.Point(20, 152);
            this.pbDog3.Margin = new System.Windows.Forms.Padding(4);
            this.pbDog3.Name = "pbDog3";
            this.pbDog3.Size = new System.Drawing.Size(103, 25);
            this.pbDog3.TabIndex = 8;
            this.pbDog3.TabStop = false;
            // 
            // pbDog2
            // 
            this.pbDog2.Image = ((System.Drawing.Image)(resources.GetObject("pbDog2.Image")));
            this.pbDog2.Location = new System.Drawing.Point(20, 94);
            this.pbDog2.Margin = new System.Windows.Forms.Padding(4);
            this.pbDog2.Name = "pbDog2";
            this.pbDog2.Size = new System.Drawing.Size(103, 25);
            this.pbDog2.TabIndex = 7;
            this.pbDog2.TabStop = false;
            // 
            // pbDog1
            // 
            this.pbDog1.Image = ((System.Drawing.Image)(resources.GetObject("pbDog1.Image")));
            this.pbDog1.Location = new System.Drawing.Point(17, 35);
            this.pbDog1.Margin = new System.Windows.Forms.Padding(4);
            this.pbDog1.Name = "pbDog1";
            this.pbDog1.Size = new System.Drawing.Size(103, 25);
            this.pbDog1.TabIndex = 6;
            this.pbDog1.TabStop = false;
            // 
            // pbRacetrack
            // 
            this.pbRacetrack.Image = ((System.Drawing.Image)(resources.GetObject("pbRacetrack.Image")));
            this.pbRacetrack.Location = new System.Drawing.Point(13, 13);
            this.pbRacetrack.Margin = new System.Windows.Forms.Padding(4);
            this.pbRacetrack.Name = "pbRacetrack";
            this.pbRacetrack.Size = new System.Drawing.Size(600, 200);
            this.pbRacetrack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbRacetrack.TabIndex = 5;
            this.pbRacetrack.TabStop = false;
            // 
            // btnRun
            // 
            this.btnRun.Location = new System.Drawing.Point(720, 506);
            this.btnRun.Name = "btnRun";
            this.btnRun.Size = new System.Drawing.Size(87, 35);
            this.btnRun.TabIndex = 10;
            this.btnRun.Text = "Go";
            this.btnRun.UseVisualStyleBackColor = true;
            this.btnRun.Click += new System.EventHandler(this.btnRun_Click);
            // 
            // btnPlaceBet
            // 
            this.btnPlaceBet.Location = new System.Drawing.Point(17, 506);
            this.btnPlaceBet.Name = "btnPlaceBet";
            this.btnPlaceBet.Size = new System.Drawing.Size(87, 35);
            this.btnPlaceBet.TabIndex = 11;
            this.btnPlaceBet.Text = "Wedt";
            this.btnPlaceBet.UseVisualStyleBackColor = true;
            this.btnPlaceBet.Click += new System.EventHandler(this.btnPlaceBet_Click);
            // 
            // rbtnPlayer1
            // 
            this.rbtnPlayer1.AutoSize = true;
            this.rbtnPlayer1.Location = new System.Drawing.Point(20, 377);
            this.rbtnPlayer1.Name = "rbtnPlayer1";
            this.rbtnPlayer1.Size = new System.Drawing.Size(102, 21);
            this.rbtnPlayer1.TabIndex = 12;
            this.rbtnPlayer1.TabStop = true;
            this.rbtnPlayer1.Text = "rbtnPlayer1";
            this.rbtnPlayer1.UseVisualStyleBackColor = true;
            // 
            // rbtnPlayer2
            // 
            this.rbtnPlayer2.AutoSize = true;
            this.rbtnPlayer2.Location = new System.Drawing.Point(20, 416);
            this.rbtnPlayer2.Name = "rbtnPlayer2";
            this.rbtnPlayer2.Size = new System.Drawing.Size(110, 21);
            this.rbtnPlayer2.TabIndex = 13;
            this.rbtnPlayer2.TabStop = true;
            this.rbtnPlayer2.Text = "radioButton2";
            this.rbtnPlayer2.UseVisualStyleBackColor = true;
            // 
            // rbtnPlayer3
            // 
            this.rbtnPlayer3.AutoSize = true;
            this.rbtnPlayer3.Location = new System.Drawing.Point(20, 456);
            this.rbtnPlayer3.Name = "rbtnPlayer3";
            this.rbtnPlayer3.Size = new System.Drawing.Size(110, 21);
            this.rbtnPlayer3.TabIndex = 14;
            this.rbtnPlayer3.TabStop = true;
            this.rbtnPlayer3.Text = "radioButton3";
            this.rbtnPlayer3.UseVisualStyleBackColor = true;
            // 
            // lbPlayer1
            // 
            this.lbPlayer1.AutoSize = true;
            this.lbPlayer1.Location = new System.Drawing.Point(504, 379);
            this.lbPlayer1.Name = "lbPlayer1";
            this.lbPlayer1.Size = new System.Drawing.Size(298, 17);
            this.lbPlayer1.TabIndex = 15;
            this.lbPlayer1.Text = "Er is momenteel geen weddenschap geplaatst";
            // 
            // lbPlayer2
            // 
            this.lbPlayer2.AutoSize = true;
            this.lbPlayer2.Location = new System.Drawing.Point(504, 418);
            this.lbPlayer2.Name = "lbPlayer2";
            this.lbPlayer2.Size = new System.Drawing.Size(298, 17);
            this.lbPlayer2.TabIndex = 16;
            this.lbPlayer2.Text = "Er is momenteel geen weddenschap geplaatst";
            // 
            // lbPlayer3
            // 
            this.lbPlayer3.AutoSize = true;
            this.lbPlayer3.Location = new System.Drawing.Point(504, 454);
            this.lbPlayer3.Name = "lbPlayer3";
            this.lbPlayer3.Size = new System.Drawing.Size(298, 17);
            this.lbPlayer3.TabIndex = 17;
            this.lbPlayer3.Text = "Er is momenteel geen weddenschap geplaatst";
            // 
            // udMoney
            // 
            this.udMoney.Location = new System.Drawing.Point(119, 511);
            this.udMoney.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.udMoney.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.udMoney.Name = "udMoney";
            this.udMoney.Size = new System.Drawing.Size(57, 22);
            this.udMoney.TabIndex = 18;
            this.udMoney.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // udDogs
            // 
            this.udDogs.Location = new System.Drawing.Point(281, 511);
            this.udDogs.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.udDogs.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.udDogs.Name = "udDogs";
            this.udDogs.Size = new System.Drawing.Size(57, 22);
            this.udDogs.TabIndex = 19;
            this.udDogs.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(182, 513);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 17);
            this.label1.TabIndex = 20;
            this.label1.Text = "euro op hond";
            // 
            // Movement
            // 
            this.Movement.Interval = 1;
            // 
            // frmBets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 553);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.udDogs);
            this.Controls.Add(this.udMoney);
            this.Controls.Add(this.lbPlayer3);
            this.Controls.Add(this.lbPlayer2);
            this.Controls.Add(this.lbPlayer1);
            this.Controls.Add(this.rbtnPlayer3);
            this.Controls.Add(this.rbtnPlayer2);
            this.Controls.Add(this.rbtnPlayer1);
            this.Controls.Add(this.btnPlaceBet);
            this.Controls.Add(this.btnRun);
            this.Controls.Add(this.pbDog4);
            this.Controls.Add(this.pbDog3);
            this.Controls.Add(this.pbDog2);
            this.Controls.Add(this.pbDog1);
            this.Controls.Add(this.pbRacetrack);
            this.Name = "frmBets";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "De Gokkers";
            this.Load += new System.EventHandler(this.frmBets_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbDog4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDog1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbRacetrack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udMoney)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.udDogs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbDog4;
        private System.Windows.Forms.PictureBox pbDog3;
        private System.Windows.Forms.PictureBox pbDog2;
        private System.Windows.Forms.PictureBox pbDog1;
        private System.Windows.Forms.PictureBox pbRacetrack;
        private System.Windows.Forms.Button btnRun;
        private System.Windows.Forms.Button btnPlaceBet;
        private System.Windows.Forms.RadioButton rbtnPlayer1;
        private System.Windows.Forms.RadioButton rbtnPlayer2;
        private System.Windows.Forms.RadioButton rbtnPlayer3;
        private System.Windows.Forms.Label lbPlayer1;
        private System.Windows.Forms.Label lbPlayer2;
        private System.Windows.Forms.Label lbPlayer3;
        private System.Windows.Forms.NumericUpDown udMoney;
        private System.Windows.Forms.NumericUpDown udDogs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer Movement;
    }
}