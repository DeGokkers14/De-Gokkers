﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeGokkers_02032018
{
    class Bet
    {
        public int Amount;
        public int Dog;
        public Guy Bettor;


        public string GetDescription(string name)
        {
            string message = name + " wedt " + this.Amount + " euro op hond " + this.Dog;
            return message;
        }

        public int PayOut(int winner)
        {
            if (winner == this.Dog)
            {
                return 0 + this.Amount;
            }

            else
            {
                return 0 - this.Amount;
            }
        }
    }
}
