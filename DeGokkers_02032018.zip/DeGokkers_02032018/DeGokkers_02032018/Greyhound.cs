﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace DeGokkers_02032018
{
    class Greyhound
    {
        public int RaceTrackLength = 500;
        public PictureBox MyPictureBox = null;
        public Random Randomizer;
        public int Position;

        public bool Run()
        {

            int speed = Randomizer.Next(10, 50);

            while(MyPictureBox.Location.X <= RaceTrackLength)
            {
                MyPictureBox.Location = new Point(MyPictureBox.Location.X + speed, MyPictureBox.Location.Y);
                Position = MyPictureBox.Location.X;
                return true;
            }

            
            return false;

        }

        public void TakeStartingPosition()
        {
            MyPictureBox.Location = new Point(15, MyPictureBox.Location.Y);
        }
    }
}
