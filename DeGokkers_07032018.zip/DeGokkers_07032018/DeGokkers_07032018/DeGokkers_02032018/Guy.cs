﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeGokkers_02032018
{
    class Guy
    {

        public string Name;
        public Bet MyBet = new Bet();
        public int Cash = 75;

        public RadioButton MyRadiobutton;
        public Label MyLabel;

        public void UpdateLabels(RadioButton radioButton)
        {
            this.MyRadiobutton = radioButton;
            MyRadiobutton.Text = this.Name + " heeft " + this.Cash + " euro";
        }

        public bool PlaceBet(int amount, int dog)
        {
            if (amount <= this.Cash)
            {
                this.MyBet.Amount = amount;
                this.MyBet.Dog = dog;

                MyLabel.Text = this.MyBet.GetDescription(this.Name);
                return true;
            }

            else
            {
                MessageBox.Show("Je kan niet meer inzetten dan je momenteel hebt");
                return false;
            }

        }

        public void ClearBet()
        {
            this.MyBet.Amount = 0;
            this.MyBet.Dog = 0;
            MyLabel.Text = "Er is momenteel geen weddenschap geplaatst";

        }

        public void Collect(int winner)
        {
            this.Cash = Cash + this.MyBet.PayOut(winner);
            this.UpdateLabels(MyRadiobutton);
        }
    }
}
