﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DeGokkers_02032018
{
    public partial class frmBets : Form
    {
        Timer time = new Timer();

        string playerName1 = frmUsernameInput.player1;
        string playerName2 = frmUsernameInput.player2;
        string playerName3 = frmUsernameInput.player3;

        // Instantiates a new class for each player 
        Guy player1 = new Guy();
        Guy player2 = new Guy();
        Guy player3 = new Guy();

        Greyhound hound1 = new Greyhound();
        Greyhound hound2 = new Greyhound();
        Greyhound hound3 = new Greyhound();
        Greyhound hound4 = new Greyhound();

        public frmBets()
        {
            InitializeComponent();
        }

        private void frmBets_Load(object sender, EventArgs e)
        {
            /* 
             * Sets player's name
             * Updates radiobutton label to start value
             */

            player1.Name = playerName1;
            player1.MyLabel = lbPlayer1;
            player1.UpdateLabels(rbtnPlayer1);

            player2.Name = playerName2;
            player2.MyLabel = lbPlayer2;
            player2.UpdateLabels(rbtnPlayer2);

            player3.Name = playerName3;
            player3.MyLabel = lbPlayer3;
            player3.UpdateLabels(rbtnPlayer3);
        }

        private void btnPlaceBet_Click(object sender, EventArgs e)
        {
            /*
             * Gets amount of money
             * Gets which dog was betted on
             */
             
            int stake = Convert.ToInt32(udMoney.Value);
            int dog = Convert.ToInt32(udDogs.Value);

            /*
             * Checks which user is betting
             * Place bet
             */ 

            if(rbtnPlayer1.Checked == true)
            {
                player1.PlaceBet(stake, dog);
            }

            if (rbtnPlayer2.Checked == true)
            {
                player2.PlaceBet(stake, dog);
            }

            if (rbtnPlayer3.Checked == true)
            {
                player3.PlaceBet(stake, dog);
            }
        }

        private void InitializeTimer()
        {
            time.Interval = 120;
            time.Enabled = true;

            time.Tick += new EventHandler(Movement_Tick);


        }

        private void Movement_Tick(object sender, EventArgs e)
        {


            if (hound1.Run() == true && hound2.Run() == true && hound3.Run() == true && hound4.Run() == true)
            {
                Movement.Enabled = true;
            }

            else
            {
                time.Enabled = false;

                int pos1 = hound1.Position;
                int pos2 = hound2.Position;
                int pos3 = hound3.Position;
                int pos4 = hound4.Position;

                if (pos1 > pos2 && pos1 > pos3 && pos1 > pos4)
                {
                    MessageBox.Show("Hond 1 wint");

                    startPos();
                    CachOut(1);
                    reset();
                }

                if (pos2 > pos1 && pos2 > pos3 && pos2 > pos4)
                {
                    MessageBox.Show("Hond 2 wint");

                    startPos();
                    CachOut(2);
                    reset();
                }

                if (pos3 > pos1 && pos3 > pos2 && pos3 > pos4)
                {
                    MessageBox.Show("Hond 3 wint");

                    startPos();
                    CachOut(3);
                    reset();
                }

                if (pos4 > pos1 && pos4 > pos2 && pos4 > pos3)
                {
                    MessageBox.Show("Hond 4 wint");

                    startPos();
                    CachOut(4);
                    reset();
                }
            }
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();

            hound1.MyPictureBox = pbDog1;
            hound2.MyPictureBox = pbDog2;
            hound3.MyPictureBox = pbDog3;
            hound4.MyPictureBox = pbDog4;

            hound1.Randomizer = rnd;
            hound2.Randomizer = rnd;
            hound3.Randomizer = rnd;
            hound4.Randomizer = rnd;


            InitializeTimer();

        }

        public void startPos()
        {
            hound1.TakeStartingPosition();
            hound2.TakeStartingPosition();
            hound3.TakeStartingPosition();
            hound4.TakeStartingPosition();
        }

        public void CachOut(int winner)
        {
            player1.Collect(winner);
            player2.Collect(winner);
            player3.Collect(winner);
        }

        public void reset()
        {
            player1.ClearBet();
            player2.ClearBet();
            player3.ClearBet();
        }
    }
}
