﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectDeGokkers
{
    class Guy
    {
        public string Name;
        public Bet MyBet = new Bet();
        public int Cash;

        public RadioButton MyRadiobutton;
        public Label MyLabel;

        public Guy(string name, RadioButton radioButton, Label label)
        {
            this.Name = name;
            this.Cash = 75;
            this.MyLabel = label;
            this.MyRadiobutton = radioButton;

        }

        public void UpdateLabels()
        {
            MyRadiobutton.Text = this.Name + " heeft " + this.Cash + " euro";
        }

        public bool PlaceBet(int amount, int dog)
        {
            if(amount <= this.Cash)
            {
                this.MyBet.Amount = amount;
                this.MyBet.Dog = dog;

                return true;
            }

            else
            {
                this.MyBet.Amount = 0;
                this.MyBet.Dog = 0;

                return false;
            }
        }

        public void ClearBet()
        {
            this.MyBet.Amount = 0;
            this.MyBet.Dog = 0;
        }

        public void Collect(int winner)
        {

        }
    }
}
