﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectDeGokkers
{
    class Greyhound
    {
        public int RaceTrackLength;
        public PictureBox MyPictureBox = null;
        public Random Randomizer;

        /*public bool Run()
        {

        }

        public void TakeStartingPosition()
        {

        }*/
    }
}
