﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectDeGokkers
{
    class Bet
    {
        public int Amount;
        public int Dog;
        public Guy Bettor;


        public void test()
        {
            MessageBox.Show(this.Amount + " " + this.Dog);
        }

        public string GetDescription()
        {
            string message = this.Bettor.Name + " wedt " + this.Amount + " euro op hond" + this.Dog; 
            return message; 
        }

        public int PayOut(int winner)
        {
            if( winner == this.Dog)
            {
                return this.Bettor.Cash + this.Amount;
            }

            else
            {
                return this.Bettor.Cash - this.Amount;
            }
        }
    }
}
