﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project6
{
    public partial class Name : Form
    {
        public Name()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // de naam van de player onthouden bij de goede player
        }

        private void label1_Click(object sender, EventArgs e)
        {
            // waar player x staat veranderen naar player die er hoort te staan
            // op die volgorde
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // naar de volende form 3 gaan en bij de laatste form3 het naar de mainscreen 
            // sturen
        }
    }
}
