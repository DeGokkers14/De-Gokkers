﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project6
{
    /*public class Greyhound
    {
        public int RaceTrackLenght; //De lengte van de renbaan
        public PictureBox MyPictureBox = null;
        public Random Randomizer; //Een instantie van Random (=Willekeurig)

        public bool Run()
        {
            //Ga willekeurig 1, 2, 3 of 4 posities naar voren.
            //Werk de positie van PictureBox bij op het formulier
            //Geef de waarde true terug als ik de race win
        }
        public void TakeStartingPosition()
        {
            //Wijzig mijn locatie naar de startlijn.
        }
    }*/
}
