﻿namespace Project6
{
    partial class Aantal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.PlayerNumber = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.Go = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Aantal Players";
            // 
            // PlayerNumber
            // 
            this.PlayerNumber.Location = new System.Drawing.Point(184, 48);
            this.PlayerNumber.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.PlayerNumber.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.PlayerNumber.Name = "PlayerNumber";
            this.PlayerNumber.Size = new System.Drawing.Size(51, 22);
            this.PlayerNumber.TabIndex = 1;
            this.PlayerNumber.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.PlayerNumber.ValueChanged += new System.EventHandler(this.PlayerNumber_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Min 3 / Max 15";
            // 
            // Go
            // 
            this.Go.Location = new System.Drawing.Point(188, 126);
            this.Go.Name = "Go";
            this.Go.Size = new System.Drawing.Size(47, 29);
            this.Go.TabIndex = 3;
            this.Go.Text = "Go";
            this.Go.UseVisualStyleBackColor = true;
            this.Go.Click += new System.EventHandler(this.Go_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(257, 167);
            this.Controls.Add(this.Go);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PlayerNumber);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "De Gokkers";
            ((System.ComponentModel.ISupportInitialize)(this.PlayerNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown PlayerNumber;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Go;
    }
}